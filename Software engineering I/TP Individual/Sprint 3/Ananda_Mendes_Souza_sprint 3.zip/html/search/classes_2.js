var searchData=
[
  ['logistic_42',['Logistic',['../class_logistic.html',1,'']]]
];
